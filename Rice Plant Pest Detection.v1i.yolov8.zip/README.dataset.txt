# Rice Plant Pest Detection > 2025-10-21 5:40am
https://universe.roboflow.com/rice-plant-pest-detection/rice-plant-pest-detection-5r6r7

Provided by a Roboflow user
License: CC BY 4.0

